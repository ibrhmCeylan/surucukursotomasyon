﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace surucuKursu
{
    public partial class FrmAnaSayfa : Form
    {
        public FrmAnaSayfa()
        {
            InitializeComponent();
        }

        private void FrmAnaSayfa_Load(object sender, EventArgs e)
        {

        }

        private void btnEgitmen_Click(object sender, EventArgs e)
        {
            FrmEgitmenDers f1 = new FrmEgitmenDers();
            f1.Show(); // Ana form kapanmaz
        }

        private void btnOgrenci_Click(object sender, EventArgs e)
        {
            frmOgrenci f2 = new frmOgrenci();
            f2.Show();
        }

        private void btnSinav_Click(object sender, EventArgs e)
        {
            FrmSinav f3 = new FrmSinav();
            f3.Show();
        }

        private void btnOdeme_Click(object sender, EventArgs e)
        {
            FrmOdeme f4 = new FrmOdeme();
            f4.Show();
        }

        private void btnEğitmen_Click(object sender, EventArgs e)
        {
            FrmEgitmen f5 =new FrmEgitmen();
            f5.Show(); 
        }
    }
}
