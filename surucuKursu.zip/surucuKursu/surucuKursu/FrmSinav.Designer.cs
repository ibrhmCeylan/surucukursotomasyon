﻿namespace surucuKursu
{
    partial class FrmSinav
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbOgrenci = new ComboBox();
            dtpTarih = new DateTimePicker();
            btnEkle = new Button();
            dgvSinavlar = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            panel1 = new Panel();
            label5 = new Label();
            pictureBox1 = new PictureBox();
            txtTeorik = new TextBox();
            txtDireksiyon = new TextBox();
            button1 = new Button();
            button2 = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvSinavlar).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // cmbOgrenci
            // 
            cmbOgrenci.Font = new Font("Segoe UI", 12F);
            cmbOgrenci.FormattingEnabled = true;
            cmbOgrenci.Location = new Point(157, 519);
            cmbOgrenci.Name = "cmbOgrenci";
            cmbOgrenci.Size = new Size(263, 36);
            cmbOgrenci.TabIndex = 0;
            // 
            // dtpTarih
            // 
            dtpTarih.Font = new Font("Segoe UI", 10F);
            dtpTarih.Location = new Point(157, 571);
            dtpTarih.Name = "dtpTarih";
            dtpTarih.Size = new Size(263, 30);
            dtpTarih.TabIndex = 1;
            // 
            // btnEkle
            // 
            btnEkle.BackColor = Color.Red;
            btnEkle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEkle.ForeColor = Color.White;
            btnEkle.Location = new Point(157, 718);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(263, 62);
            btnEkle.TabIndex = 4;
            btnEkle.Text = "EKLE";
            btnEkle.UseVisualStyleBackColor = false;
            btnEkle.Click += btnKaydet_Click;
            // 
            // dgvSinavlar
            // 
            dgvSinavlar.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSinavlar.Location = new Point(458, 115);
            dgvSinavlar.Name = "dgvSinavlar";
            dgvSinavlar.RowHeadersWidth = 51;
            dgvSinavlar.Size = new Size(1432, 906);
            dgvSinavlar.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(63, 522);
            label1.Name = "label1";
            label1.Size = new Size(88, 28);
            label1.TabIndex = 6;
            label1.Text = "Öğrenci:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(91, 572);
            label2.Name = "label2";
            label2.Size = new Size(60, 28);
            label2.TabIndex = 7;
            label2.Text = "Tarih:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(78, 622);
            label3.Name = "label3";
            label3.Size = new Size(73, 28);
            label3.TabIndex = 8;
            label3.Text = "Teorik:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(38, 671);
            label4.Name = "label4";
            label4.Size = new Size(113, 28);
            label4.TabIndex = 9;
            label4.Text = "Direksiyon:";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Red;
            panel1.Controls.Add(label5);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1902, 91);
            panel1.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 22.2F, FontStyle.Bold);
            label5.ForeColor = Color.White;
            label5.Location = new Point(854, 21);
            label5.Name = "label5";
            label5.Size = new Size(133, 50);
            label5.TabIndex = 0;
            label5.Text = "SINAV";
            // 
            // pictureBox1
            // 
            pictureBox1.Location = new Point(35, 115);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(385, 385);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            // 
            // txtTeorik
            // 
            txtTeorik.Font = new Font("Segoe UI", 12F);
            txtTeorik.Location = new Point(157, 619);
            txtTeorik.Name = "txtTeorik";
            txtTeorik.Size = new Size(263, 34);
            txtTeorik.TabIndex = 12;
            // 
            // txtDireksiyon
            // 
            txtDireksiyon.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtDireksiyon.Location = new Point(157, 668);
            txtDireksiyon.Name = "txtDireksiyon";
            txtDireksiyon.Size = new Size(263, 34);
            txtDireksiyon.TabIndex = 13;
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(157, 786);
            button1.Name = "button1";
            button1.Size = new Size(263, 62);
            button1.TabIndex = 14;
            button1.Text = "SİL";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.Red;
            button2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            button2.ForeColor = Color.White;
            button2.Location = new Point(157, 854);
            button2.Name = "button2";
            button2.Size = new Size(263, 62);
            button2.TabIndex = 15;
            button2.Text = "GÜNCELLE";
            button2.UseVisualStyleBackColor = false;
            // 
            // FrmSinav
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1902, 1033);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(txtDireksiyon);
            Controls.Add(txtTeorik);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dgvSinavlar);
            Controls.Add(btnEkle);
            Controls.Add(dtpTarih);
            Controls.Add(cmbOgrenci);
            Name = "FrmSinav";
            Text = "Sinav";
            Load += FrmSinav_Load;
            ((System.ComponentModel.ISupportInitialize)dgvSinavlar).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbOgrenci;
        private DateTimePicker dtpTarih;
        private NumericUpDown nudTeorik;
        private NumericUpDown nudDireksiyon;
        private Button btnEkle;
        private DataGridView dgvSinavlar;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Panel panel1;
        private PictureBox pictureBox1;
        private TextBox txtTeorik;
        private TextBox txtDireksiyon;
        private Label label5;
        private Button button1;
        private Button button2;
    }
}