﻿namespace surucuKursu
{
    partial class frmOgrenci
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmOgrenci));
            txtAd = new TextBox();
            txtSoyad = new TextBox();
            txtTelefon = new TextBox();
            txtTC = new TextBox();
            dtpDogum = new DateTimePicker();
            dtpBaslangic = new DateTimePicker();
            cmbEhliyet = new ComboBox();
            btnEkle = new Button();
            btnSil = new Button();
            btnGuncelle = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            dgvOgrenciler = new DataGridView();
            panel1 = new Panel();
            label8 = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dgvOgrenciler).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // txtAd
            // 
            txtAd.Font = new Font("Segoe UI", 12F);
            txtAd.Location = new Point(165, 515);
            txtAd.Name = "txtAd";
            txtAd.Size = new Size(250, 34);
            txtAd.TabIndex = 0;
            // 
            // txtSoyad
            // 
            txtSoyad.Font = new Font("Segoe UI", 12F);
            txtSoyad.Location = new Point(165, 564);
            txtSoyad.Name = "txtSoyad";
            txtSoyad.Size = new Size(250, 34);
            txtSoyad.TabIndex = 1;
            // 
            // txtTelefon
            // 
            txtTelefon.Font = new Font("Segoe UI", 12F);
            txtTelefon.Location = new Point(165, 670);
            txtTelefon.Name = "txtTelefon";
            txtTelefon.Size = new Size(250, 34);
            txtTelefon.TabIndex = 2;
            // 
            // txtTC
            // 
            txtTC.Font = new Font("Segoe UI", 12F);
            txtTC.Location = new Point(165, 616);
            txtTC.Name = "txtTC";
            txtTC.Size = new Size(250, 34);
            txtTC.TabIndex = 3;
            // 
            // dtpDogum
            // 
            dtpDogum.Font = new Font("Segoe UI", 10F);
            dtpDogum.Location = new Point(165, 724);
            dtpDogum.Name = "dtpDogum";
            dtpDogum.Size = new Size(250, 30);
            dtpDogum.TabIndex = 4;
            // 
            // dtpBaslangic
            // 
            dtpBaslangic.Font = new Font("Segoe UI", 10F);
            dtpBaslangic.Location = new Point(165, 774);
            dtpBaslangic.Name = "dtpBaslangic";
            dtpBaslangic.Size = new Size(250, 30);
            dtpBaslangic.TabIndex = 5;
            // 
            // cmbEhliyet
            // 
            cmbEhliyet.Font = new Font("Segoe UI", 11F);
            cmbEhliyet.FormattingEnabled = true;
            cmbEhliyet.Location = new Point(165, 820);
            cmbEhliyet.Name = "cmbEhliyet";
            cmbEhliyet.Size = new Size(250, 33);
            cmbEhliyet.TabIndex = 6;
            // 
            // btnEkle
            // 
            btnEkle.BackColor = Color.Red;
            btnEkle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEkle.ForeColor = Color.White;
            btnEkle.Location = new Point(165, 868);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(250, 47);
            btnEkle.TabIndex = 7;
            btnEkle.Text = "EKLE";
            btnEkle.UseVisualStyleBackColor = false;
            btnEkle.Click += btnEkle_Click;
            // 
            // btnSil
            // 
            btnSil.BackColor = Color.Red;
            btnSil.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSil.ForeColor = Color.White;
            btnSil.Location = new Point(165, 921);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(250, 47);
            btnSil.TabIndex = 8;
            btnSil.Text = "SİL";
            btnSil.UseVisualStyleBackColor = false;
            btnSil.Click += btnSil_Click;
            // 
            // btnGuncelle
            // 
            btnGuncelle.BackColor = Color.Red;
            btnGuncelle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnGuncelle.ForeColor = Color.White;
            btnGuncelle.Location = new Point(165, 974);
            btnGuncelle.Name = "btnGuncelle";
            btnGuncelle.Size = new Size(250, 47);
            btnGuncelle.TabIndex = 9;
            btnGuncelle.Text = "GÜNCELLE";
            btnGuncelle.UseVisualStyleBackColor = false;
            btnGuncelle.Click += btnGuncelle_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label1.Location = new Point(117, 518);
            label1.Name = "label1";
            label1.Size = new Size(42, 28);
            label1.TabIndex = 10;
            label1.Text = "Ad:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label2.Location = new Point(87, 567);
            label2.Name = "label2";
            label2.Size = new Size(72, 28);
            label2.TabIndex = 11;
            label2.Text = "Soyad:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label3.Location = new Point(120, 619);
            label3.Name = "label3";
            label3.Size = new Size(39, 28);
            label3.TabIndex = 12;
            label3.Text = "TC:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label4.Location = new Point(75, 673);
            label4.Name = "label4";
            label4.Size = new Size(84, 28);
            label4.TabIndex = 13;
            label4.Text = "Telefon:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label5.Location = new Point(20, 724);
            label5.Name = "label5";
            label5.Size = new Size(139, 28);
            label5.TabIndex = 14;
            label5.Text = "Doğum Tarihi:";
            label5.Click += label5_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label6.Location = new Point(58, 774);
            label6.Name = "label6";
            label6.Size = new Size(101, 28);
            label6.TabIndex = 15;
            label6.Text = "Başlangıç:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label7.Location = new Point(87, 820);
            label7.Name = "label7";
            label7.Size = new Size(77, 28);
            label7.TabIndex = 16;
            label7.Text = "Ehliyet:";
            // 
            // dgvOgrenciler
            // 
            dgvOgrenciler.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvOgrenciler.Location = new Point(458, 115);
            dgvOgrenciler.Name = "dgvOgrenciler";
            dgvOgrenciler.RowHeadersWidth = 51;
            dgvOgrenciler.Size = new Size(1432, 906);
            dgvOgrenciler.TabIndex = 17;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Red;
            panel1.Controls.Add(label8);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1902, 91);
            panel1.TabIndex = 18;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 22.2F, FontStyle.Bold);
            label8.ForeColor = Color.White;
            label8.Location = new Point(831, 20);
            label8.Name = "label8";
            label8.Size = new Size(361, 50);
            label8.TabIndex = 19;
            label8.Text = "ÖĞRENCİ BİLGİLERİ";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(30, 115);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(385, 385);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 19;
            pictureBox1.TabStop = false;
            // 
            // frmOgrenci
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1902, 1033);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Controls.Add(dgvOgrenciler);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnGuncelle);
            Controls.Add(btnSil);
            Controls.Add(btnEkle);
            Controls.Add(cmbEhliyet);
            Controls.Add(dtpBaslangic);
            Controls.Add(dtpDogum);
            Controls.Add(txtTC);
            Controls.Add(txtTelefon);
            Controls.Add(txtSoyad);
            Controls.Add(txtAd);
            Name = "frmOgrenci";
            Text = "Öğrenci";
            Load += frmOgrenci_Load;
            ((System.ComponentModel.ISupportInitialize)dgvOgrenciler).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtAd;
        private TextBox txtSoyad;
        private TextBox txtTelefon;
        private TextBox txtTC;
        private DateTimePicker dtpDogum;
        private DateTimePicker dtpBaslangic;
        private ComboBox cmbEhliyet;
        private Button btnEkle;
        private Button btnSil;
        private Button btnGuncelle;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private DataGridView dgvOgrenciler;
        private Panel panel1;
        private Label label8;
        private PictureBox pictureBox1;
    }
}
