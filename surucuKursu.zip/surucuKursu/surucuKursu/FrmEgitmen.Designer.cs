﻿namespace surucuKursu
{
    partial class FrmEgitmen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmEgitmen));
            txtAd = new TextBox();
            txtSoyad = new TextBox();
            txtTelefon = new TextBox();
            txtBrans = new TextBox();
            btnEkle = new Button();
            btnSil = new Button();
            btnGuncelle = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            dgvEgitmenler = new DataGridView();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvEgitmenler).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // txtAd
            // 
            txtAd.Font = new Font("Segoe UI", 12F);
            txtAd.Location = new Point(129, 537);
            txtAd.Name = "txtAd";
            txtAd.Size = new Size(292, 34);
            txtAd.TabIndex = 0;
            // 
            // txtSoyad
            // 
            txtSoyad.Font = new Font("Segoe UI", 12F);
            txtSoyad.Location = new Point(129, 591);
            txtSoyad.Name = "txtSoyad";
            txtSoyad.Size = new Size(292, 34);
            txtSoyad.TabIndex = 1;
            // 
            // txtTelefon
            // 
            txtTelefon.Font = new Font("Segoe UI", 12F);
            txtTelefon.Location = new Point(129, 646);
            txtTelefon.Name = "txtTelefon";
            txtTelefon.Size = new Size(292, 34);
            txtTelefon.TabIndex = 2;
            // 
            // txtBrans
            // 
            txtBrans.Font = new Font("Segoe UI", 12F);
            txtBrans.Location = new Point(129, 702);
            txtBrans.Name = "txtBrans";
            txtBrans.Size = new Size(292, 34);
            txtBrans.TabIndex = 3;
            // 
            // btnEkle
            // 
            btnEkle.BackColor = Color.Red;
            btnEkle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEkle.ForeColor = Color.White;
            btnEkle.Location = new Point(129, 753);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(292, 55);
            btnEkle.TabIndex = 4;
            btnEkle.Text = "EKLE";
            btnEkle.UseVisualStyleBackColor = false;
            // 
            // btnSil
            // 
            btnSil.BackColor = Color.Red;
            btnSil.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            btnSil.ForeColor = Color.White;
            btnSil.Location = new Point(129, 814);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(292, 55);
            btnSil.TabIndex = 5;
            btnSil.Text = "SİL";
            btnSil.UseVisualStyleBackColor = false;
            // 
            // btnGuncelle
            // 
            btnGuncelle.BackColor = Color.Red;
            btnGuncelle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            btnGuncelle.ForeColor = Color.White;
            btnGuncelle.Location = new Point(129, 875);
            btnGuncelle.Name = "btnGuncelle";
            btnGuncelle.Size = new Size(292, 55);
            btnGuncelle.TabIndex = 6;
            btnGuncelle.Text = "GÜNCELLE";
            btnGuncelle.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label1.Location = new Point(81, 540);
            label1.Name = "label1";
            label1.Size = new Size(42, 28);
            label1.TabIndex = 7;
            label1.Text = "Ad:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label2.Location = new Point(51, 594);
            label2.Name = "label2";
            label2.Size = new Size(72, 28);
            label2.TabIndex = 8;
            label2.Text = "Soyad:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label3.Location = new Point(39, 649);
            label3.Name = "label3";
            label3.Size = new Size(84, 28);
            label3.TabIndex = 9;
            label3.Text = "Telefon:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label4.Location = new Point(56, 705);
            label4.Name = "label4";
            label4.Size = new Size(67, 28);
            label4.TabIndex = 10;
            label4.Text = "Branş:";
            // 
            // dgvEgitmenler
            // 
            dgvEgitmenler.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvEgitmenler.Location = new Point(458, 115);
            dgvEgitmenler.Name = "dgvEgitmenler";
            dgvEgitmenler.RowHeadersWidth = 51;
            dgvEgitmenler.Size = new Size(1432, 906);
            dgvEgitmenler.TabIndex = 11;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Red;
            panel1.Controls.Add(label5);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1902, 91);
            panel1.TabIndex = 12;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(36, 115);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(385, 385);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 13;
            pictureBox1.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 22.2F, FontStyle.Bold);
            label5.ForeColor = Color.White;
            label5.Location = new Point(892, 22);
            label5.Name = "label5";
            label5.Size = new Size(186, 50);
            label5.TabIndex = 14;
            label5.Text = "EĞİTMEN";
            // 
            // FrmEgitmen
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1902, 1033);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Controls.Add(dgvEgitmenler);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnGuncelle);
            Controls.Add(btnSil);
            Controls.Add(btnEkle);
            Controls.Add(txtBrans);
            Controls.Add(txtTelefon);
            Controls.Add(txtSoyad);
            Controls.Add(txtAd);
            Name = "FrmEgitmen";
            Text = "FrmEgitmen";
            Load += FrmEgitmen_Load;
            ((System.ComponentModel.ISupportInitialize)dgvEgitmenler).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtAd;
        private TextBox txtSoyad;
        private TextBox txtTelefon;
        private TextBox txtBrans;
        private Button btnEkle;
        private Button btnSil;
        private Button btnGuncelle;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private DataGridView dgvEgitmenler;
        private Panel panel1;
        private PictureBox pictureBox1;
        private Label label5;
    }
}