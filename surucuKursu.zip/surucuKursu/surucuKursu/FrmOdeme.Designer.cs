﻿namespace surucuKursu
{
    partial class FrmOdeme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmOdeme));
            cmbOgrenci = new ComboBox();
            txtMiktar = new TextBox();
            txtAciklama = new TextBox();
            dtpTarih = new DateTimePicker();
            btnEkle = new Button();
            btnSil = new Button();
            lblToplam = new Label();
            dgvOdeme = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            btnGuncelle = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvOdeme).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // cmbOgrenci
            // 
            cmbOgrenci.DrawMode = DrawMode.OwnerDrawFixed;
            cmbOgrenci.Font = new Font("Segoe UI", 11F);
            cmbOgrenci.FormattingEnabled = true;
            cmbOgrenci.Location = new Point(169, 518);
            cmbOgrenci.Name = "cmbOgrenci";
            cmbOgrenci.Size = new Size(250, 33);
            cmbOgrenci.TabIndex = 0;
            // 
            // txtMiktar
            // 
            txtMiktar.Font = new Font("Segoe UI", 12F);
            txtMiktar.Location = new Point(169, 571);
            txtMiktar.Name = "txtMiktar";
            txtMiktar.Size = new Size(250, 34);
            txtMiktar.TabIndex = 1;
            // 
            // txtAciklama
            // 
            txtAciklama.Font = new Font("Segoe UI", 12F);
            txtAciklama.Location = new Point(169, 626);
            txtAciklama.Multiline = true;
            txtAciklama.Name = "txtAciklama";
            txtAciklama.Size = new Size(250, 83);
            txtAciklama.TabIndex = 2;
            // 
            // dtpTarih
            // 
            dtpTarih.Font = new Font("Segoe UI", 10F);
            dtpTarih.Location = new Point(169, 730);
            dtpTarih.Name = "dtpTarih";
            dtpTarih.Size = new Size(250, 30);
            dtpTarih.TabIndex = 3;
            // 
            // btnEkle
            // 
            btnEkle.BackColor = Color.Red;
            btnEkle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEkle.ForeColor = Color.White;
            btnEkle.Location = new Point(169, 780);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(250, 48);
            btnEkle.TabIndex = 4;
            btnEkle.Text = "EKLE";
            btnEkle.UseVisualStyleBackColor = false;
            btnEkle.Click += btnEkle_Click;
            // 
            // btnSil
            // 
            btnSil.BackColor = Color.Red;
            btnSil.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSil.ForeColor = Color.White;
            btnSil.Location = new Point(169, 834);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(250, 48);
            btnSil.TabIndex = 5;
            btnSil.Text = "SİL";
            btnSil.UseVisualStyleBackColor = false;
            btnSil.Click += btnSil_Click;
            // 
            // lblToplam
            // 
            lblToplam.AutoSize = true;
            lblToplam.Font = new Font("Segoe UI", 12F);
            lblToplam.Location = new Point(169, 952);
            lblToplam.Name = "lblToplam";
            lblToplam.Size = new Size(76, 28);
            lblToplam.TabIndex = 6;
            lblToplam.Text = "Toplam";
            // 
            // dgvOdeme
            // 
            dgvOdeme.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            dgvOdeme.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvOdeme.Location = new Point(458, 115);
            dgvOdeme.Name = "dgvOdeme";
            dgvOdeme.RowHeadersWidth = 51;
            dgvOdeme.Size = new Size(1432, 906);
            dgvOdeme.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(66, 518);
            label1.Name = "label1";
            label1.Size = new Size(88, 28);
            label1.TabIndex = 8;
            label1.Text = "Öğrenci:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(78, 574);
            label2.Name = "label2";
            label2.Size = new Size(76, 28);
            label2.TabIndex = 9;
            label2.Text = "Miktar:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(56, 629);
            label3.Name = "label3";
            label3.Size = new Size(98, 28);
            label3.TabIndex = 10;
            label3.Text = "Açıklama:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(94, 730);
            label4.Name = "label4";
            label4.Size = new Size(60, 28);
            label4.TabIndex = 11;
            label4.Text = "Tarih:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.FromArgb(255, 0, 6);
            label5.Font = new Font("Segoe UI", 22.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(809, 21);
            label5.Name = "label5";
            label5.Size = new Size(344, 50);
            label5.TabIndex = 12;
            label5.Text = "ÖDEME İŞLEMLERİ";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(255, 0, 6);
            panel1.Controls.Add(label5);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1902, 91);
            panel1.TabIndex = 13;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(34, 115);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(385, 385);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 15;
            pictureBox1.TabStop = false;
            // 
            // btnGuncelle
            // 
            btnGuncelle.BackColor = Color.Red;
            btnGuncelle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnGuncelle.ForeColor = Color.White;
            btnGuncelle.Location = new Point(169, 888);
            btnGuncelle.Name = "btnGuncelle";
            btnGuncelle.Size = new Size(250, 48);
            btnGuncelle.TabIndex = 16;
            btnGuncelle.Text = "GÜNCELLE";
            btnGuncelle.UseVisualStyleBackColor = false;
            // 
            // FrmOdeme
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1902, 1033);
            Controls.Add(btnGuncelle);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dgvOdeme);
            Controls.Add(lblToplam);
            Controls.Add(btnSil);
            Controls.Add(btnEkle);
            Controls.Add(dtpTarih);
            Controls.Add(txtAciklama);
            Controls.Add(txtMiktar);
            Controls.Add(cmbOgrenci);
            Name = "FrmOdeme";
            Text = "Ödeme";
            Load += FrmOdeme_Load;
            ((System.ComponentModel.ISupportInitialize)dgvOdeme).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbOgrenci;
        private TextBox txtMiktar;
        private TextBox txtAciklama;
        private DateTimePicker dtpTarih;
        private Button btnEkle;
        private Button btnSil;
        private Label lblToplam;
        private DataGridView dgvOdeme;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Panel panel1;
        private PictureBox pictureBox1;
        private Button btnGuncelle;
    }
}