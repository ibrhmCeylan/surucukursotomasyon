﻿namespace surucuKursu
{
    partial class FrmAnaSayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAnaSayfa));
            btnOgrenci = new Button();
            btnEgitmenDers = new Button();
            btnSinav = new Button();
            btnOdeme = new Button();
            btnEğitmen = new Button();
            panel1 = new Panel();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnOgrenci
            // 
            btnOgrenci.BackColor = Color.Red;
            btnOgrenci.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            btnOgrenci.ForeColor = Color.White;
            btnOgrenci.Location = new Point(758, 805);
            btnOgrenci.Name = "btnOgrenci";
            btnOgrenci.Size = new Size(1110, 67);
            btnOgrenci.TabIndex = 0;
            btnOgrenci.Text = "ÖĞRENCİ";
            btnOgrenci.UseVisualStyleBackColor = false;
            btnOgrenci.Click += btnOgrenci_Click;
            // 
            // btnEgitmenDers
            // 
            btnEgitmenDers.BackColor = Color.Red;
            btnEgitmenDers.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            btnEgitmenDers.ForeColor = Color.White;
            btnEgitmenDers.Location = new Point(758, 586);
            btnEgitmenDers.Name = "btnEgitmenDers";
            btnEgitmenDers.Size = new Size(1110, 67);
            btnEgitmenDers.TabIndex = 1;
            btnEgitmenDers.Text = "EĞİTMEN DERS";
            btnEgitmenDers.UseVisualStyleBackColor = false;
            btnEgitmenDers.Click += btnEgitmen_Click;
            // 
            // btnSinav
            // 
            btnSinav.BackColor = Color.Red;
            btnSinav.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            btnSinav.ForeColor = Color.White;
            btnSinav.Location = new Point(758, 659);
            btnSinav.Name = "btnSinav";
            btnSinav.Size = new Size(1110, 67);
            btnSinav.TabIndex = 2;
            btnSinav.Text = "SINAV";
            btnSinav.UseVisualStyleBackColor = false;
            btnSinav.Click += btnSinav_Click;
            // 
            // btnOdeme
            // 
            btnOdeme.BackColor = Color.Red;
            btnOdeme.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            btnOdeme.ForeColor = Color.White;
            btnOdeme.Location = new Point(758, 878);
            btnOdeme.Name = "btnOdeme";
            btnOdeme.Size = new Size(1110, 67);
            btnOdeme.TabIndex = 3;
            btnOdeme.Text = "ÖDEME";
            btnOdeme.UseVisualStyleBackColor = false;
            btnOdeme.Click += btnOdeme_Click;
            // 
            // btnEğitmen
            // 
            btnEğitmen.BackColor = Color.Red;
            btnEğitmen.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            btnEğitmen.ForeColor = Color.White;
            btnEğitmen.Location = new Point(758, 732);
            btnEğitmen.Name = "btnEğitmen";
            btnEğitmen.Size = new Size(1110, 67);
            btnEğitmen.TabIndex = 4;
            btnEğitmen.Text = "EĞİTMEN";
            btnEğitmen.UseVisualStyleBackColor = false;
            btnEğitmen.Click += btnEğitmen_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Red;
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1902, 91);
            panel1.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 22.2F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(851, 20);
            label1.Name = "label1";
            label1.Size = new Size(222, 50);
            label1.TabIndex = 6;
            label1.Text = "ANA SAYFA";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(31, 143);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(691, 727);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(758, 143);
            label2.Name = "label2";
            label2.Size = new Size(1024, 420);
            label2.TabIndex = 7;
            label2.Text = resources.GetString("label2.Text");
            // 
            // FrmAnaSayfa
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1902, 1033);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Controls.Add(btnEğitmen);
            Controls.Add(btnOdeme);
            Controls.Add(btnSinav);
            Controls.Add(btnEgitmenDers);
            Controls.Add(btnOgrenci);
            Name = "FrmAnaSayfa";
            Text = "Ana Sayfa";
            Load += FrmAnaSayfa_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnOgrenci;
        private Button btnEgitmenDers;
        private Button btnSinav;
        private Button btnOdeme;
        private Button btnEğitmen;
        private Panel panel1;
        private Label label1;
        private PictureBox pictureBox1;
        private Label label2;
    }
}