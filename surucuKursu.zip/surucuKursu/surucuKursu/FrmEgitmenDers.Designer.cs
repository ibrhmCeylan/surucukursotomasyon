﻿namespace surucuKursu
{
    partial class FrmEgitmenDers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmEgitmenDers));
            cmbEgitmen = new ComboBox();
            cmbOgrenci = new ComboBox();
            cmbSaat = new ComboBox();
            cmbDersTuru = new ComboBox();
            dtpTarih = new DateTimePicker();
            btnEkle = new Button();
            dgvProgram = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            panel1 = new Panel();
            label6 = new Label();
            pictureBox1 = new PictureBox();
            btnSil = new Button();
            btnGuncelle = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvProgram).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // cmbEgitmen
            // 
            cmbEgitmen.Font = new Font("Segoe UI", 12F);
            cmbEgitmen.FormattingEnabled = true;
            cmbEgitmen.Location = new Point(176, 520);
            cmbEgitmen.Name = "cmbEgitmen";
            cmbEgitmen.Size = new Size(245, 36);
            cmbEgitmen.TabIndex = 0;
            // 
            // cmbOgrenci
            // 
            cmbOgrenci.Font = new Font("Segoe UI", 12F);
            cmbOgrenci.FormattingEnabled = true;
            cmbOgrenci.Location = new Point(176, 572);
            cmbOgrenci.Name = "cmbOgrenci";
            cmbOgrenci.Size = new Size(245, 36);
            cmbOgrenci.TabIndex = 1;
            // 
            // cmbSaat
            // 
            cmbSaat.Font = new Font("Segoe UI", 12F);
            cmbSaat.FormattingEnabled = true;
            cmbSaat.Location = new Point(176, 624);
            cmbSaat.Name = "cmbSaat";
            cmbSaat.Size = new Size(245, 36);
            cmbSaat.TabIndex = 2;
            // 
            // cmbDersTuru
            // 
            cmbDersTuru.Font = new Font("Segoe UI", 12F);
            cmbDersTuru.FormattingEnabled = true;
            cmbDersTuru.Location = new Point(176, 677);
            cmbDersTuru.Name = "cmbDersTuru";
            cmbDersTuru.Size = new Size(245, 36);
            cmbDersTuru.TabIndex = 3;
            // 
            // dtpTarih
            // 
            dtpTarih.Font = new Font("Segoe UI", 10F);
            dtpTarih.Location = new Point(176, 726);
            dtpTarih.Name = "dtpTarih";
            dtpTarih.Size = new Size(245, 30);
            dtpTarih.TabIndex = 4;
            // 
            // btnEkle
            // 
            btnEkle.BackColor = Color.Red;
            btnEkle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEkle.ForeColor = Color.White;
            btnEkle.Location = new Point(176, 772);
            btnEkle.Name = "btnEkle";
            btnEkle.Size = new Size(245, 55);
            btnEkle.TabIndex = 5;
            btnEkle.Text = "EKLE";
            btnEkle.UseVisualStyleBackColor = false;
            btnEkle.Click += btnKaydet_Click;
            // 
            // dgvProgram
            // 
            dgvProgram.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvProgram.Location = new Point(458, 115);
            dgvProgram.Name = "dgvProgram";
            dgvProgram.RowHeadersWidth = 51;
            dgvProgram.Size = new Size(1432, 906);
            dgvProgram.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label1.Location = new Point(78, 523);
            label1.Name = "label1";
            label1.Size = new Size(92, 28);
            label1.TabIndex = 7;
            label1.Text = "Eğitmen:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label2.Location = new Point(82, 575);
            label2.Name = "label2";
            label2.Size = new Size(88, 28);
            label2.TabIndex = 8;
            label2.Text = "Öğrenci:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label3.Location = new Point(115, 627);
            label3.Name = "label3";
            label3.Size = new Size(55, 28);
            label3.TabIndex = 9;
            label3.Text = "Saat:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label4.Location = new Point(66, 680);
            label4.Name = "label4";
            label4.Size = new Size(104, 28);
            label4.TabIndex = 10;
            label4.Text = "Ders Türü:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            label5.Location = new Point(110, 726);
            label5.Name = "label5";
            label5.Size = new Size(60, 28);
            label5.TabIndex = 11;
            label5.Text = "Tarih:";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Red;
            panel1.Controls.Add(label6);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1902, 91);
            panel1.TabIndex = 12;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 22.2F, FontStyle.Bold);
            label6.ForeColor = Color.White;
            label6.Location = new Point(796, 21);
            label6.Name = "label6";
            label6.Size = new Size(322, 50);
            label6.TabIndex = 13;
            label6.Text = "DERS PROGRAMI";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(36, 115);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(385, 385);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 13;
            pictureBox1.TabStop = false;
            // 
            // btnSil
            // 
            btnSil.BackColor = Color.Red;
            btnSil.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSil.ForeColor = Color.White;
            btnSil.Location = new Point(176, 833);
            btnSil.Name = "btnSil";
            btnSil.Size = new Size(245, 50);
            btnSil.TabIndex = 14;
            btnSil.Text = "SİL";
            btnSil.UseVisualStyleBackColor = false;
            // 
            // btnGuncelle
            // 
            btnGuncelle.BackColor = Color.Red;
            btnGuncelle.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnGuncelle.ForeColor = Color.White;
            btnGuncelle.Location = new Point(176, 889);
            btnGuncelle.Name = "btnGuncelle";
            btnGuncelle.Size = new Size(245, 56);
            btnGuncelle.TabIndex = 15;
            btnGuncelle.Text = "GÜNCELLE";
            btnGuncelle.UseVisualStyleBackColor = false;
            // 
            // FrmEgitmenDers
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1902, 1033);
            Controls.Add(btnGuncelle);
            Controls.Add(btnSil);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dgvProgram);
            Controls.Add(btnEkle);
            Controls.Add(dtpTarih);
            Controls.Add(cmbDersTuru);
            Controls.Add(cmbSaat);
            Controls.Add(cmbOgrenci);
            Controls.Add(cmbEgitmen);
            Name = "FrmEgitmenDers";
            Text = "Egitmen Ders";
            Load += FrmEgitmenDers_Load;
            ((System.ComponentModel.ISupportInitialize)dgvProgram).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cmbEgitmen;
        private ComboBox cmbOgrenci;
        private ComboBox cmbSaat;
        private ComboBox cmbDersTuru;
        private DateTimePicker dtpTarih;
        private Button btnEkle;
        private DataGridView dgvProgram;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Panel panel1;
        private Label label6;
        private PictureBox pictureBox1;
        private Button btnSil;
        private Button btnGuncelle;
    }
}