﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace surucuKursu
{
    public partial class FrmSinav : Form
    {
        public FrmSinav()
        {
            InitializeComponent();
        }

        private void FrmSinav_Load(object sender, EventArgs e)
        {
            pictureBox1.Image = Properties.Resources.logo;
        }

        private void btnKaydet_Click(object sender, EventArgs e)
        {
            
        }
        void SinavListele()
        {
        }
    }
}
